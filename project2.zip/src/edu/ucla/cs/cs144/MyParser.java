/* CS144
 *
 * Parser skeleton for processing item-???.xml files. Must be compiled in
 * JDK 1.5 or above.
 *
 * Instructions:
 *
 * This program processes all files passed on the command line (to parse
 * an entire diectory, type "java MyParser myFiles/*.xml" at the shell).
 *
 * At the point noted below, an individual XML file has been parsed into a
 * DOM Document node. You should fill in code to process the node. Java's
 * interface for the Document Object Model (DOM) is in package
 * org.w3c.dom. The documentation is available online at
 *
 * http://java.sun.com/j2se/1.5.0/docs/api/index.html
 *
 * A tutorial of Java's XML Parsing can be found at:
 *
 * http://java.sun.com/webservices/jaxp/
 *
 * Some auxiliary methods have been written for you. You may find them
 * useful.
 
 */

package edu.ucla.cs.cs144;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ErrorHandler;

class MyParser
{

	static final String columnSeparator = "|*|";
	static DocumentBuilder builder;

	static final String[] typeName =
	{ "none", "Element", "Attr", "Text", "CDATA", "EntityRef", "Entity", "ProcInstr", "Comment", "Document", "DocType",
			"DocFragment", "Notation", };
	
	private static ArrayList <MonsterBean> m_monsterBeanList = new ArrayList <MonsterBean>();
	
	public static String convertDate(String time) throws ParseException
	{
		// Create a format that parses from XML date format into Java Date format
		String expectedPattern = "MMM-dd-yy HH:mm:ss";
        SimpleDateFormat format = new SimpleDateFormat(expectedPattern);   
        
		// Parse from passed in XML date to Java Date
        Date date = format.parse(time);
		
		// Create formatter to convert from Java Date to desired MySQL timestamp format
        String desiredPattern = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat format2 = new SimpleDateFormat(desiredPattern);
		
		// Format from Java Date to timestamp format. Return
		String convertedDate = format2.format(date);
		return convertedDate;
    }
	
	// Files are: Auction.csv, User.csv, Bids.csv, Buy_Price.csv, Category.csv
	public static void writeFile(String fileName) throws IOException, ParseException
	{
		char branch = 'X';
		if (fileName.equals("Auction.csv"))
		{
			branch = 'A';
		}
		if (fileName.equals("User.csv"))
		{
			branch = 'U';
		}
		if (fileName.equals("Bids.csv"))
		{
			branch = 'B';
		}
		if (fileName.equals("Buy_Price.csv"))
		{
			branch = 'P';
		}
		if (fileName.equals("Category.csv"))
		{
			branch = 'C';
		}

		// Initialize file and filewriter to write to file
		FileWriter fWriter;
		File file = new File(fileName);
		if (!file.exists())
		{
			try
			{
				fWriter = new FileWriter(fileName);
			}
			catch (Exception e)
			{
				System.out.println("Creation of " + fileName + " failed.");
				return;
			}
		}
		else
		{
			System.out.println(fileName + " exists already somehow.");
			return;
		}

		switch (branch)
		{
		// AUCTION(ItemID, Name, Currently, First_Bid, Number_of_Bids, Started,
		// Ends, Seller, Description)
			case 'A':
				for (int i = 0; i < m_monsterBeanList.size(); i++)
				{
					String output = "";
					// ItemID, Name, Currently, First_Bid, Number_of_Bids
					MonsterBean mBean = m_monsterBeanList.get(i);
					output += Integer.toString(mBean.getItemID());

					output += "~~|}" + mBean.getName() + "~~|}";
					output += strip(mBean.getCurrently()) + "~~|}";
					output += strip(mBean.getFirstBid()) + "~~|}";
					output += Integer.toString(mBean.getNumBids()) + "~~|}";

					// Parse time strings
					output += convertDate(mBean.getStarted()) + "~~|}";
					output += convertDate(mBean.getEnds()) + "~~|}";

					// UserID, Description
					output += mBean.getUser().getUserID();
					//output += ",NULL\n";
					output += "~~|}" + processString(mBean.getDesc()) + "\n";
					fWriter.write(output);
				}
				break;

			// USER(UserID, Rating, Location, Country)
			case 'U':
				for (int i = 0; i < m_monsterBeanList.size(); i++)
				{
					// Grab seller information
					String output = "";
					User user = m_monsterBeanList.get(i).getUser();
					output += user.getUserID() + "~~|}";
					output += Integer.toString(user.getRating());
					output += "~~|}" + user.getLocation() + "~~|}" + user.getCountry() + "~~|}\n";
					fWriter.write(output);

					// Grab all bidder information associated with item
					ArrayList<Bid> bidList = m_monsterBeanList.get(i).getBidList();
					for (int j = 0; j < bidList.size(); j++)
					{
						output = "";
						User bidder = bidList.get(j).getUser();
						output += bidder.getUserID() + "~~|}";
						output += Integer.toString(bidder.getRating());
						// Surround with quotes for present location
						if (bidder.getLocation().equals("NULL"))
						{
							output += "~~|}" + bidder.getLocation();
						}
						else
						{
							output += "~~|}" + bidder.getLocation();
						}

						// Surround with quotes for present country
						if (bidder.getCountry().equals("NULL"))
						{
							output += "~~|}" + bidder.getCountry() + "\n";
						}
						else
						{
							output += "~~|}" + bidder.getCountry() + "\n";
						}
						fWriter.write(output);
					}
				}
				break;

			// BIDS(BidderID, Time, Amount, ItemID)
			case 'B':
				for (int i = 0; i < m_monsterBeanList.size(); i++)
				{
					ArrayList<Bid> bidList = m_monsterBeanList.get(i).getBidList();
					for (int j = 0; j < bidList.size(); j++)
					{
						String output = "";
						// BidderID
						output += (bidList.get(j).getUser().getUserID()) + "~~|}";

						// Some magic to parse the time into what mySQL wants
						output += convertDate(bidList.get(j).getTime()) + "~~|}";

						// Amount, ItemID
						output += strip(bidList.get(j).getAmount()) + "~~|}";
						output += Integer.toString(m_monsterBeanList.get(i).getItemID()) + "\n";
						fWriter.write(output);
					}
				}
				break;

			// BUY_PRICE(ItemID, Buy_Price)
			case 'P':
				for (int i = 0; i < m_monsterBeanList.size(); i++)
				{
					String output = "";
					MonsterBean mBean = m_monsterBeanList.get(i);
					// If no buy price, no need to add another record
					if (mBean.getBuyPrice().equals("NULL"))
					{
						continue;
					}
					output += Integer.toString(mBean.getItemID()) + ",";
					output += strip(mBean.getBuyPrice()) + "\n";
					fWriter.write(output);
				}
				break;

			// CATEGORY(ItemID, Category)
			case 'C':
				for (int i = 0; i < m_monsterBeanList.size(); i++)
				{
					String itemID = Integer.toString(m_monsterBeanList.get(i).getItemID());
					ArrayList<String> catList = m_monsterBeanList.get(i).getCategoryList();
					for (int j = 0; j < catList.size(); j++)
					{
						String output = "";
						output += itemID + "~~|}";
						output += catList.get(j) + "\n";
						fWriter.write(output);
					}
				}
				break;

			default:
				System.out.println("We should not have gotten here.");
				break;
		}

		try
		{
			fWriter.close();
		}
		catch (IOException e)
		{
			System.out.println("Failed to close file writer.");
		}
	}

	// Truncates strings to 4000 characters, as specified in the spec
	public static String processString (String input)
	{
		if (input.length() > 4000)
		{
			return input.substring(0, 3999);
		}
		else
		{
			return input;
		}
	}

	static class MyErrorHandler implements ErrorHandler
	{

		public void warning(SAXParseException exception) throws SAXException
		{
			fatalError(exception);
		}

		public void error(SAXParseException exception) throws SAXException
		{
			fatalError(exception);
		}

		public void fatalError(SAXParseException exception) throws SAXException
		{
			exception.printStackTrace();
			System.out.println("There should be no errors " + "in the supplied XML files.");
			System.exit(3);
		}

	}

	/*
	 * Non-recursive (NR) version of Node.getElementsByTagName(...)
	 */
	static Element[] getElementsByTagNameNR(Element e, String tagName)
	{
		Vector<Element> elements = new Vector<Element>();
		Node child = e.getFirstChild();
		while (child != null)
		{
			if (child instanceof Element && child.getNodeName().equals(tagName))
			{
				elements.add((Element) child);
			}
			child = child.getNextSibling();
		}
		Element[] result = new Element[elements.size()];
		elements.copyInto(result);
		return result;
	}

	/*
	 * Returns the first subelement of e matching the given tagName, or null if
	 * one does not exist. NR means Non-Recursive.
	 */
	static Element getElementByTagNameNR(Element e, String tagName)
	{
		Node child = e.getFirstChild();
		while (child != null)
		{
			if (child instanceof Element && child.getNodeName().equals(tagName))
				return (Element) child;
			child = child.getNextSibling();
		}
		return null;
	}

	/*
	 * Returns the text associated with the given element (which must have type
	 * #PCDATA) as child, or "" if it contains no text.
	 */
	static String getElementText(Element e)
	{
		if (e.getChildNodes().getLength() == 1)
		{
			Text elementText = (Text) e.getFirstChild();
			return elementText.getNodeValue();
		}
		else
			return "";
	}

	/*
	 * Returns the text (#PCDATA) associated with the first subelement X of e
	 * with the given tagName. If no such X exists or X contains no text, "" is
	 * returned. NR means Non-Recursive.
	 */
	static String getElementTextByTagNameNR(Element e, String tagName)
	{
		Element elem = getElementByTagNameNR(e, tagName);
		if (elem != null)
			return getElementText(elem);
		else
			return "";
	}

	/*
	 * Returns the amount (in XXXXX.xx format) denoted by a money-string like
	 * $3,453.23. Returns the input if the input is an empty string.
	 */
	static String strip(String money)
	{
		if (money.equals(""))
			return money;
		else
		{
			double am = 0.0;
			NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
			try
			{
				am = nf.parse(money).doubleValue();
			}
			catch (ParseException e)
			{
				System.out.println("This method should work for all " + "money values you find in our data.");
				System.exit(20);
			}
			nf.setGroupingUsed(false);
			return nf.format(am).substring(1);
		}
	}

	/*
	 * Process one items-???.xml file.
	 */
	static void processFile(File xmlFile)
	{
		Document doc = null;
		try
		{
			doc = builder.parse(xmlFile);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			System.exit(3);
		}
		catch (SAXException e)
		{
			System.out.println("Parsing error on file " + xmlFile);
			System.out.println("  (not supposed to happen with supplied XML files)");
			e.printStackTrace();
			System.exit(3);
		}

		/*
		 * At this point 'doc' contains a DOM representation of an 'Items' XML
		 * file. Use doc.getDocumentElement() to get the root Element.
		 */
		System.out.println("Successfully parsed - " + xmlFile);

		/*
		 * Fill in code here (you will probably need to write auxiliary
		 * methods).
		 */
		
		// Parse the XML file into MonsterBeans, which hold all information relevant to an item
		// JUSTIN, DO THIS
		
		// Array of elements that contains the element nodes for all the "item" tags
        Element[] items = getElementsByTagNameNR(doc.getDocumentElement(), "Item");
        //System.out.println(items.length); //prints out the number of items there are in the xml file (test out all the code)
        MonsterBean monster;
        
        for (int i = 0; i < items.length; ++i)
        {
           		monster = new MonsterBean(); //temp MonsterBean variable that extracts data needed from the item node
            	setMonsterItemID(monster, items[i]);
        		setMonsterName(monster, items[i]);
                setMonsterCategory(monster, items[i]);
                setMonsterCurrently(monster, items[i]);
                setMonsterBuyPrice(monster,items[i]);
                setMonsterFirstBid(monster, items[i]);
                setMonsterNumBids(monster, items[i]);
                
                setMonsterBids(monster, items[i]);
                
                setMonsterStarted(monster, items[i]);
                setMonsterEnds(monster, items[i]);
                
                setMonsterItemUser(monster, items[i]);
                
                setMonsterDesc(monster, items[i]);
                
                m_monsterBeanList.add(monster); //add the monsterbean to the end of the monsterbean arraylist whoooo
                //garbage collector is awsomeeee
        }
		/**************************************************************/
	}
	
	/*
     * functions that extract the elements and attributes of items, functions listed in order of the xml file for easier access
     * Element Item**GIVEN/PASSED
     * >Attr ItemID (done)
     *         >Element Name (done)
     *         >Element Category+ (done)
     *         >Element Currently (done)
     *         >Element Buy_Price? (done)
     *         >Element First_Bid (done)
     *         >Element Number_of_Bids (done)
     *         Element Bids
     *                 >Element Bid* (done)
     *                         Element Bidder
     *                         >Attr UserID, Rating (done, done)
     *                                 >Element Location? (done)
     *                                 >Element Country? (done)
     *                         >Element Time (done)
     *                         >Element Amount (done)
     *         >Element Location (done)
     *         >Element Country (done)
     *         >Element Started (done)
     *         >Element Ends (done)
     *         Element Seller
     *         >Attr UserID, Rating (done, done)
     *         >Element Description (done)
     */
    
    /*
     * set the ItemID element in the monsterbean passed, to the given parent
     */
    public static void setMonsterItemID(MonsterBean monster, Element Item)
    {
            Node nodeItemID;
            int m_itemID;
            nodeItemID = Item.getAttributeNode("ItemID"); //get the attribute named ItemID
            m_itemID = Integer.parseInt(nodeItemID.getNodeValue());	//get the value of the attribute and typecast string to int
            monster.setItemID(m_itemID); //set the ItemID of the monsterbean to the value retreived
    }
    
    /*
     * sets the Name element in the monsterbean passed, to the name of the item that was passed
     */
    public static void setMonsterName(MonsterBean monster, Element Item)
    {
            String name;
            name = getElementTextByTagNameNR(Item, "Name"); //get the value under the 'name' tag
            monster.setName(name); //set the value retrieved from above function
            //System.out.println("Name: " + monster.getName()); //test print function to see if it worked correctly
    }
    
    /*
     * set the Category element of the monsterbean passed, to the categories of the item that was passed (note that category is another arraylist of strings)
     */
    public static void setMonsterCategory(MonsterBean monster, Element Item)
    {
            Element[] categories = getElementsByTagNameNR(Item, "Category"); //get an array of category element nodes
            String category;
            for (int i = 0; i < categories.length; ++i) //loop through the array of category element nodes
            {
                    category = getElementText(categories[i]); //get the text of the element
                    monster.appendCategory(category); //the set method of the category, we append here because it's an arraylist
            }
    }
    
    /*
     * set the Currently element of the monsterbean passed, to the currently of the item that was passed
     */
    public static void setMonsterCurrently(MonsterBean monster, Element Item)
    {
            String currently;
            currently = getElementTextByTagNameNR(Item, "Currently"); //get the value under the 'currently' tag
            monster.setCurrently(currently); //set the value retreived from above function
            //System.out.println("Currently: " + monster.getCurrently()); //test print function to see if it worked correctly
    }

    /*
     * set the Buy_Price element of the monsterbean passed, to the buy price of the item that was passed
     */
    public static void setMonsterBuyPrice(MonsterBean monster, Element Item)
    {
            String buyPrice;
            buyPrice = getElementTextByTagNameNR(Item, "Buy_Price"); //get the value under the 'buy_price' tag
            if (!buyPrice.equals(""))
            {
            	monster.setBuyPrice(buyPrice); //set the value retreived from the above function
            }
            //System.out.println("Buy Price: " + monster.getBuyPrice()); //test print function to see if it worked correctly
    }

    /*
     * set the First_Bid element of the monsterbean passed, to the first bid of the item that was passed
     */
    public static void setMonsterFirstBid(MonsterBean monster, Element Item)
    {
            String firstBid;
            firstBid = getElementTextByTagNameNR(Item, "First_Bid"); //get the value under the 'first_bid' tag
            monster.setFirstBid(firstBid); //set the value retreived from the above function
            //System.out.println("First Bid: " + monster.getFirstBid()); //test print function to see if it worked correctly
    }

    /*
     * set the Number_of_Bids element of the monsterbean passed, to the number of bids of the item that was passed
     */
    public static void setMonsterNumBids(MonsterBean monster, Element Item)
    {
            String s_numBids;
            int i_numBids;
            s_numBids = getElementTextByTagNameNR(Item, "Number_of_Bids"); //get the value under the 'number_of_bids' tag
            i_numBids = Integer.parseInt(s_numBids); //convert the value to integer since the bean it's being sent to has it as an int type
            monster.setNumBids(i_numBids); //set the value retreived from the above two functions
            //System.out.println("Number of Bids: " + monster.getNumBids()); //test print function to see if it worked correctly
    }
    
    /*
     * Gets all the bids and extract info for it. Implement same way as the items iterate through itself
     */
    public static void setMonsterBids(MonsterBean monster, Element Item)                //WORK ON DIS SHIT TOOOOOOO
    {
            //Array of elements that contains the element nodes for all the "Bid" tags
    		Element findBids = getElementByTagNameNR(Item, "Bids");
            Element[] bids = getElementsByTagNameNR(findBids, "Bid");
            Bid monsterBid;
            for(int i = 0; i < bids.length; ++i)
            {
            	monsterBid = new Bid();
            	setMonsterBidUser(monsterBid, bids[i]);
            	setMonsterBidTime(monsterBid, bids[i]);
            	setMonsterBidAmount(monsterBid, bids[i]);
            	monster.appendBid(monsterBid);
            }
    }
    
    /*
     * set the UserID attribute of the bidder in the monsterbean passed
     */
    public static void setMonsterBidUser(Bid bidder, Element bid)
    {
    	User monsterBidUser = new User();
    	Element elementBidUser = getElementByTagNameNR(bid, "Bidder");	//bidder tag, holds attributes for UserID and rating, userid and rating setter function wants element node that holds these attributes or BOOOOOOM
    	setMonsterUserID(monsterBidUser, elementBidUser);				//pass the elementBidUser since it's at the correct element node position
    	setMonsterRating(monsterBidUser, elementBidUser);				//same for this one. whoo
    	setMonsterLocation(monsterBidUser, elementBidUser);				//and dis
    	setMonsterCountry(monsterBidUser, elementBidUser);				//and thiiiiiiiiiiiiiis
    	bidder.setUser(monsterBidUser);
    }
    
    /******************************************************/
    /*
     * user aux functions(methods.. booo java boooo)
     * use for both item owner and bidder
     */
    //attribute values assum the element node passed is on the tag holding the attributes
    public static void setMonsterUserID(User user, Element node)
    {
    	Node nodeUserID;
    	String m_userID;
    	nodeUserID = node.getAttributeNode("UserID");			//get the attribute node under 'UserID'
    	m_userID = nodeUserID.getNodeValue();					//get node value
    	user.setUserID(m_userID);								//use setter function. yay
    }
    //attribute values assum the element node passed is on the tag holding the attributes
    public static void setMonsterRating(User user, Element node)
    {
    	Node nodeRating;
    	int m_rating;
    	nodeRating = node.getAttributeNode("Rating");			//get the attribute node under 'Rating'
    	m_rating = Integer.parseInt(nodeRating.getNodeValue());	//get node value
    	user.setRating(m_rating);								//use setter functiooooon
    }
    //find and set the location ele value
    public static void setMonsterLocation(User user, Element node)
    {
    	//rinse and repeat
    	String location;
    	location = getElementTextByTagNameNR(node, "Location");
    	if (!location.equals(""))
    	{
    		user.setLocation(location);
    	}
    	//System.out.println(user.getLocation());
    }
    //find and set the country ele value
    public static void setMonsterCountry(User user, Element node)
    {
    	//and repeat again
    	String country;
    	country = getElementTextByTagNameNR(node, "Country");
    	if (!country.equals(""))
    	{
    		user.setCountry(country);
    	}
    	//System.out.println(user.getCountry());
    }
    /*
     * end of user aux functions
     */
    /*********************************************************/
    
    /*
     * set the time element of the bid element into the bid bean passed
     */
     
    public static void setMonsterBidTime(Bid bidder, Element bid)
    {
    	//the same deal going on here as above
    	String time;
    	time = getElementTextByTagNameNR(bid, "Time");
    	bidder.setTime(time);
    }
    
    /*
     * set the amount element of the bid element into the bid bean passed
     */
    public static void setMonsterBidAmount(Bid bidder, Element bid)
    {
    	//the same deal going on here as above
    	String amount;
    	amount = getElementTextByTagNameNR(bid, "Amount");
    	bidder.setAmount(amount);
    }

    /*
     * setting the item seller user
     */
    public static void setMonsterItemUser(MonsterBean monster, Element Item)
    {
    	User monsterUser = new User();
    	Element elementItemUser = getElementByTagNameNR(Item, "Seller");	//find the Seller ele tag because userid and rating set functions assume element node is in the position holding the attr nodes
    	setMonsterUserID(monsterUser, elementItemUser);		//assign userid attr value
    	setMonsterRating(monsterUser, elementItemUser);		//assign rating attr value
    	setMonsterLocation(monsterUser, Item);				//assign location ele value
    	setMonsterCountry(monsterUser, Item);				//assign country ele value
    	monster.setUser(monsterUser);		//set to the big ole monsta
    }
    
    /*
     * set the started element of the monsterbean passed, to the started of the item that was passed
     */
    public static void setMonsterStarted(MonsterBean monster, Element Item)
    {
            String started;
            started = getElementTextByTagNameNR(Item, "Started"); //get the value under the 'started' tag
            monster.setStarted(started); //set the value retreived from the above function
            //System.out.println("Started: " + monster.getStarted()); //test print function to see if it worked correctly
    }
    
    /*
     * set the ends element of the monsterbean passed, to the ends of the item that was passed
     */
    public static void setMonsterEnds(MonsterBean monster, Element Item)
    {
            String ends;
            ends = getElementTextByTagNameNR(Item, "Ends"); //get the value under the 'ends' tag
            monster.setEnds(ends); //set the value retreived from the above function
            //System.out.println("Ends: " + monster.getEnds()); //test print function to see if it worked correctly
    }
    
    /*
     * set the description element of the monsterbean passed, to the description of the item that was passed
     */
    public static void setMonsterDesc(MonsterBean monster, Element Item)
    {
            String desc;
            desc = getElementTextByTagNameNR(Item, "Description"); //get the value under the 'description' tag
            monster.setDesc(desc); //set the value retreived from the above function
            //System.out.println("Desc: " + monster.getDesc()); //test print function to see if it worked correctly
    }
	
	public static void recursiveDescent(Node n, int level)
	{
		// adjust indentation according to level
		for (int i = 0; i < 4 * level; i++)
			System.out.print(" ");

		// dump out node name, type, and value
		String ntype = typeName[n.getNodeType()];
		String nname = n.getNodeName();
		String nvalue = n.getNodeValue();

		System.out.println("Type = " + ntype + ", Name = " + nname + ", Value = " + nvalue);

		// dump out attributes if any
		org.w3c.dom.NamedNodeMap nattrib = n.getAttributes();
		if (nattrib != null && nattrib.getLength() > 0)
			for (int i = 0; i < nattrib.getLength(); i++)
				recursiveDescent(nattrib.item(i), level + 1);

		// now walk through its children list
		org.w3c.dom.NodeList nlist = n.getChildNodes();

		for (int i = 0; i < nlist.getLength(); i++)
			recursiveDescent(nlist.item(i), level + 1);
	}

	public static void main(String[] args) throws IOException, ParseException
	{
		if (args.length == 0)
		{
			System.out.println("Usage: java MyParser [file] [file] ...");
			System.exit(1);
		}

		/* Initialize parser. */
		try
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setValidating(false);
			factory.setIgnoringElementContentWhitespace(true);
			builder = factory.newDocumentBuilder();
			builder.setErrorHandler(new MyErrorHandler());
		}
		catch (FactoryConfigurationError e)
		{
			System.out.println("unable to get a document builder factory");
			System.exit(2);
		}
		catch (ParserConfigurationException e)
		{
			System.out.println("parser was unable to be configured");
			System.exit(2);
		}

		/* Process all files listed on command line. */
		for (int i = 0; i < args.length; i++)
		{
			File currentFile = new File(args[i]);
			processFile(currentFile);
		}
		
		// Read from our ArrayList of MonsterBeans into our 5 files, one per table
		// Now we create the files
		// Files are: Auction.csv, User.csv, Bids.csv, Buy_Price.csv, Category.csv
		// Fields are comma terminated, records are new line terminated
		
		writeFile("Auction.csv");
		writeFile("User.csv");
		writeFile("Bids.csv");
		writeFile("Buy_Price.csv");
		writeFile("Category.csv");
	}
}
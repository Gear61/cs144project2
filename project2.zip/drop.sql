use CS144;

drop table if exists Ebay_Users;
drop table if exists Auction;
drop table if exists Bids;
drop table if exists Buy_Price;
drop table if exists Category;